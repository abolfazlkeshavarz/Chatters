package handlers

import (
	"net/http"

	"messenger/internal/db"

	"github.com/gin-gonic/gin"
)

func GetMessages(c *gin.Context) {
	chatID := c.Param("chatId")
	userID := c.GetString("user_id")

	// ✅ Security check: is user a member of this chat?
	var exists bool
	err := db.DB.QueryRow(
		`SELECT EXISTS (
			SELECT 1 FROM chat_members
			WHERE chat_id = $1 AND user_id = $2
		)`,
		chatID,
		userID,
	).Scan(&exists)

	if err != nil || !exists {
		c.JSON(http.StatusForbidden, gin.H{"error": "not a chat member"})
		return
	}

	// ✅ Load messages
	rows, err := db.DB.Query(
		`SELECT sender_id, content, created_at
		 FROM messages
		 WHERE chat_id = $1
		 ORDER BY created_at ASC`,
		chatID,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
		return
	}
	defer rows.Close()

	var messages []gin.H

	for rows.Next() {
		var sender, content string
		var createdAt string

		rows.Scan(&sender, &content, &createdAt)

		messages = append(messages, gin.H{
			"from": sender,
			"text": content,
			"time": createdAt,
		})
	}

	c.JSON(http.StatusOK, messages)
}
