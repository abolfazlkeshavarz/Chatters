package handlers

import (
	"net/http"

	"messenger/internal/db"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func CreateChat(c *gin.Context) {
	var req struct {
		Members []string `json:"members"`
		IsGroup bool     `json:"is_group"`
	}

	if err := c.BindJSON(&req); err != nil || len(req.Members) < 2 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request"})
		return
	}

	chatID := uuid.New()

	// create chat
	_, err := db.DB.Exec(
		"INSERT INTO chats (id, is_group) VALUES ($1, $2)",
		chatID,
		req.IsGroup,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
		return
	}

	// add members
	for _, user := range req.Members {
		_, _ = db.DB.Exec(
			"INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2)",
			chatID,
			user,
		)
	}

	c.JSON(http.StatusOK, gin.H{"chat_id": chatID})
}

func GetChats(c *gin.Context) {
	userID := c.GetString("user_id")

	rows, err := db.DB.Query(
		`SELECT c.id, c.is_group
		 FROM chats c
		 JOIN chat_members m ON m.chat_id = c.id
		 WHERE m.user_id = $1`,
		userID,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
		return
	}
	defer rows.Close()

	var chats []gin.H

	for rows.Next() {
		var id string
		var isGroup bool
		rows.Scan(&id, &isGroup)

		chats = append(chats, gin.H{
			"id":       id,
			"is_group": isGroup,
		})
	}

	c.JSON(http.StatusOK, chats)
}
func AddMember(c *gin.Context) {
	chatID := c.Param("id")

	var req struct {
		UserID string `json:"user_id"`
	}
	if err := c.BindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request"})
		return
	}

	_, err := db.DB.Exec(
		"INSERT INTO chat_members (chat_id, user_id) VALUES ($1, $2)",
		chatID,
		req.UserID,
	)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "user already in chat"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"status": "member added"})
}
