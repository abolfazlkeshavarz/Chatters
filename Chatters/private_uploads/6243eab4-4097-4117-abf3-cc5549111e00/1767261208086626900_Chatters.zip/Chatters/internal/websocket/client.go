package websocket

import "github.com/gorilla/websocket"

type Client struct {
	UserID string
	Conn   *websocket.Conn
	Send   chan []byte
}

func readPump(hub *Hub, client *Client) {
	defer func() {
		hub.Unregister <- client
		client.Conn.Close()
	}()

	for {
		var msg ChatMessage
		err := client.Conn.ReadJSON(&msg)
		if err != nil {
			// 🔑 DO NOT panic, just exit cleanly
			return
		}

		msg.From = client.UserID
		hub.Incoming <- msg
	}
}

func writePump(c *Client) {
	defer c.Conn.Close()

	for msg := range c.Send {
		c.Conn.WriteMessage(websocket.TextMessage, msg)
	}
}
