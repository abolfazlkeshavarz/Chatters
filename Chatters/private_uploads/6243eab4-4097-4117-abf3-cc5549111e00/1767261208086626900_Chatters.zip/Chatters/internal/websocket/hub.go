package websocket

import "messenger/internal/db"

type Hub struct {
	Clients    map[string]*Client
	Register   chan *Client
	Unregister chan *Client
	Incoming   chan ChatMessage
}

type ChatMessage struct {
	ChatID  string `json:"chat_id"`
	From    string `json:"from"`
	Content string `json:"content"`
}

func NewHub() *Hub {
	return &Hub{
		Clients:    make(map[string]*Client),
		Register:   make(chan *Client),
		Unregister: make(chan *Client),
		Incoming:   make(chan ChatMessage),
	}
}

func (h *Hub) getChatMembers(chatID string) ([]string, error) {
	rows, err := db.DB.Query(
		"SELECT user_id FROM chat_members WHERE chat_id = $1",
		chatID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var members []string
	for rows.Next() {
		var userID string
		if err := rows.Scan(&userID); err == nil {
			members = append(members, userID)
		}
	}
	return members, nil
}

func (h *Hub) Run() {
	for {
		select {

		case client := <-h.Register:
			h.Clients[client.UserID] = client

		case client := <-h.Unregister:
			delete(h.Clients, client.UserID)
			close(client.Send)

		case msg := <-h.Incoming:
			members, err := h.getChatMembers(msg.ChatID)
			if err != nil {
				continue
			}

			for _, userID := range members {
				if client, ok := h.Clients[userID]; ok {
					client.Send <- []byte(msg.From + ": " + msg.Content)
				}
			}
		}
	}
}
